
import React from 'react';
import {
  View,
  Text,
  Image,
  SectionList,
  TouchableOpacity,
  StyleSheet,
  Alert,
} from 'react-native';

const datasource = [
  {
    title: 'JAPANESE SPORTS CARS',
    bgcolor: '#B3D9F2',
    data: [
      {
        key: 'Nissan GT-R',
        description: 'Japanese Sports Car',
        picture: require('./img/nissan.jpg'),
      },
      {
        key: 'Toyota Supra',
        description: 'Japanese Sports Car',
        picture: require('./img/supra.jpg'),
      },
    ],
  },
  {
    title: 'EUROPEAN SPORTS CARS',
    bgcolor: '#F2B6B6',
    data: [
      {
        key: 'Porsche 911',
        description: 'European Sports Car',
        picture: require('./img/porsche.jpg'),
      },
      {
        key: 'BMW M4',
        description: 'European Sports Car',
        picture: require('./img/bmw.jpg'),
      },
    ],
  },
];

const MyApp = () => {

  const renderItem = ({item}) => {
    return (
      <TouchableOpacity
        style={styles.card}
        onPress={() => Alert.alert(item.key)}
      >
        <View style={styles.details}>
          <Text style={styles.carName}>
            {item.key}
          </Text>

          <Text style={styles.description}>
            {item.description}
          </Text>
        </View>

        <Image
          source={item.picture}
          style={styles.carImage}
          resizeMode="contain"
        />
      </TouchableOpacity>
    );
  };

  return (
    <View style={styles.container}>

      <Text style={styles.title}>
        SPORTS CAR COLLECTION
      </Text>

      <Text style={styles.subtitle}>
        Explore Japanese and European Sports Cars
      </Text>

      <SectionList
        sections={datasource}
        renderItem={renderItem}
        renderSectionHeader={({section: {title, bgcolor}}) => (
          <Text
            style={[styles.headerText, {backgroundColor: bgcolor}]}
          >
            {title}
          </Text>
        )}
        contentContainerStyle={styles.list}
      />

    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F2F2F2',
    paddingTop: 40,
  },

  title: {
    fontSize: 24,
    fontWeight: 'bold',
    textAlign: 'center',
    color: '#222222',
    marginTop: 10,
  },

  subtitle: {
    fontSize: 14,
    textAlign: 'center',
    color: '#555555',
    marginTop: 5,
    marginBottom: 15,
  },

  list: {
    paddingHorizontal: 15,
    paddingBottom: 20,
  },

  headerText: {
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
    padding: 12,
    marginTop: 15,
    borderWidth: 1,
    borderColor: '#AAAAAA',
  },

  card: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: 'white',
    borderWidth: 1,
    borderColor: '#CCCCCC',
    padding: 12,
    marginBottom: 5,
  },

  details: {
    flex: 1,
    justifyContent: 'center',
  },

  carName: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#222222',
  },

  description: {
    fontSize: 13,
    color: '#666666',
    marginTop: 5,
  },

  carImage: {
    width: 130,
    height: 120,
  },
});

export default MyApp;
