import React from 'react';
import {View, Text, Image} from 'react-native';
import {Picker} from '@react-native-picker/picker';

const Question = ({number, image, option1, option2, option3, option4, answer, onValueChange}) => {
  return (
    <View>
      <Image
  source={image}
  style={{width: '100%', height: 250}}
  resizeMode="contain"
/>

      <Text>Question {number}: Who is this boxer?</Text>

      <Picker selectedValue={answer} onValueChange={(value) => {
        console.log(value);
        onValueChange(value);
      }}>
        <Picker.Item label="Select an item..." value=""/>
        <Picker.Item label={option1} value={option1}/>
        <Picker.Item label={option2} value={option2}/>
        <Picker.Item label={option3} value={option3}/>
        <Picker.Item label={option4} value={option4}/>
      </Picker>
    </View>
  );
};

export default Question;