
import React from 'react';
import {View, Text, Image, StyleSheet} from 'react-native';

function Boat(props) {
  return (
    <View style={styles.card}>

      <Image
        source={props.picture}
        style={styles.image}
        resizeMode="cover"
      />

      <View style={styles.details}>

        <View style={styles.nameRow}>
          <Text style={styles.name}>
            {props.name}
          </Text>

          <Text style={styles.number}>
            #{props.number}
          </Text>
        </View>

        <Text style={styles.description}>
          {props.description}
        </Text>

        <View style={styles.bottomRow}>
          <Text style={styles.category}>
            POWERBOAT
          </Text>
        </View>

      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: 'white',
    marginHorizontal: 15,
    marginBottom: 18,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: '#D5E2EB',
    overflow: 'hidden',
    elevation: 4,
  },

  image: {
    width: '100%',
    height: 210,
  },

  details: {
    padding: 16,
  },

  nameRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 10,
  },

  name: {
    flex: 1,
    fontSize: 20,
    fontWeight: 'bold',
    color: '#173B57',
  },

  number: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#4C829F',
    marginLeft: 10,
  },

  description: {
    fontSize: 14,
    lineHeight: 22,
    color: '#444444',
    marginBottom: 15,
  },

  bottomRow: {
    flexDirection: 'row',
    justifyContent: 'flex-end',
    alignItems: 'center',
  },

  category: {
    backgroundColor: '#E5F1F7',
    color: '#173B57',
    fontSize: 12,
    fontWeight: 'bold',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 8,
  },
});

export default Boat;
