
import React from 'react';
import {
  View,
  Text,
  ScrollView,
  StyleSheet,
  StatusBar,
} from 'react-native';

import Boat from './components/Boat';

const boats = [
  {
    name: 'Sea Ray 500 Sundancer',
    description:
      'Contoured lines and dramatic styling reveal a refined and powerful presence that will take your breath away.',
    picture: require('./img/sea_ray.jpg'),
  },
  {
    name: 'Four Winns Horizon 180',
    description:
      'A sporty look and refined details truly set the Horizon 180 above all others.',
    picture: require('./img/four_winns.jpg'),
  },
  {
    name: 'Flipper 640 ST',
    description:
      'A modern take on the classic, traditional hardtop and perfect for a family picnic.',
    picture: require('./img/flipper.jpg'),
  },
  {
    name: 'Princess V48',
    description:
      'There is the option for an open design with a full-length cockpit and sunroof, or the enclosed deck saloon model, available with the option of a climate controlled interior.',
    picture: require('./img/princess.jpg'),
  },
  {
    name: 'Bayliner 175 Bowrider',
    description:
      'Its outboard power gives you increased cockpit space and quiet, fuel-efficient performance.',
    picture: require('./img/bayliner.jpg'),
  },
  {
    name: 'Fairline Targa 47',
    description:
      'Stretch out on the large sun bed aft while friends lounge in the generously appointed cockpit.',
    picture: require('./img/fairline.jpg'),
  },
];

export default function App() {
  return (
    <View style={styles.container}>
      <StatusBar barStyle="light-content" />

      <View style={styles.header}>
        <View style={styles.headerRow}>
          <Text style={styles.title}>⚓ GetABoat</Text>

          <View style={styles.boatCount}>
            <Text style={styles.countText}>
              {boats.length} BOATS
            </Text>
          </View>
        </View>

        <Text style={styles.subtitle}>
          Discover our collection of powerboats
        </Text>
      </View>

      <ScrollView contentContainerStyle={styles.boatList}>
        <Text style={styles.sectionTitle}>
          Available Powerboats
        </Text>

        {boats.map((boat, index) => (
          <Boat
            key={index}
            number={index + 1}
            name={boat.name}
            description={boat.description}
            picture={boat.picture}
          />
        ))}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#EDF3F8',
  },

  header: {
    backgroundColor: '#173B57',
    paddingTop: 45,
    paddingBottom: 25,
    paddingHorizontal: 20,
    borderBottomWidth: 4,
    borderBottomColor: '#4C9AB5',
  },

  headerRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },

  title: {
    color: 'white',
    fontSize: 28,
    fontWeight: 'bold',
  },

  boatCount: {
    backgroundColor: '#315D7A',
    paddingHorizontal: 12,
    paddingVertical: 7,
    borderRadius: 15,
  },

  countText: {
    color: 'white',
    fontSize: 12,
    fontWeight: 'bold',
  },

  subtitle: {
    color: '#D7E7F2',
    fontSize: 15,
    marginTop: 8,
  },

  boatList: {
    paddingVertical: 15,
    paddingBottom: 30,
  },

  sectionTitle: {
    fontSize: 21,
    fontWeight: 'bold',
    color: '#173B57',
    marginHorizontal: 15,
    marginBottom: 10,
  },
});
