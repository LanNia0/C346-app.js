
import React from 'react';
import {View, Text, Image, StyleSheet} from 'react-native';
import {Picker} from '@react-native-picker/picker';

const Question = ({number, image, option1, option2, option3, option4, answer, onValueChange}) => {
  return (
    <View style={styles.card}>

      <View style={styles.questionHeader}>
        <Text style={styles.questionNumber}>
          QUESTION {number}
        </Text>

        <Text style={styles.questionText}>
          Who is this boxer?
        </Text>
      </View>

      <View style={styles.imageContainer}>
        <Image
          source={image}
          style={styles.image}
          resizeMode="contain"
        />
      </View>

      <View style={styles.answerContainer}>
        <Text style={styles.answerLabel}>SELECT YOUR ANSWER</Text>

        <View style={styles.pickerBox}>
          <Picker
            selectedValue={answer}
            onValueChange={(value) => {
              console.log(value);
              onValueChange(value);
            }}
          >
            <Picker.Item label="Select an item..." value=""/>
            <Picker.Item label={option1} value={option1}/>
            <Picker.Item label={option2} value={option2}/>
            <Picker.Item label={option3} value={option3}/>
            <Picker.Item label={option4} value={option4}/>
          </Picker>
        </View>
      </View>

    </View>
  );
};

const styles = StyleSheet.create({
  card: {
    backgroundColor: 'white',
    marginBottom: 18,
    borderWidth: 1,
    borderColor: '#DDDDDD',
    borderRadius: 12,
    overflow: 'hidden',
    elevation: 3,
  },

  questionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: '#222222',
    padding: 12,
  },

  questionNumber: {
    color: '#FFFFFF',
    fontSize: 13,
    fontWeight: 'bold',
  },

  questionText: {
    color: '#FFFFFF',
    fontSize: 13,
  },

  imageContainer: {
    backgroundColor: '#F2F2F2',
    justifyContent: 'center',
    alignItems: 'center',
    height: 240,
  },

  image: {
    width: '100%',
    height: 230,
  },

  answerContainer: {
    padding: 12,
  },

  answerLabel: {
    color: '#B91C1C',
    fontSize: 12,
    fontWeight: 'bold',
    marginBottom: 8,
  },

  pickerBox: {
    borderWidth: 1,
    borderColor: '#CCCCCC',
    borderRadius: 8,
    backgroundColor: '#FFFFFF',
  },
});

export default Question;
