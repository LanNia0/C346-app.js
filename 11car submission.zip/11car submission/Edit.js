
import React, {useState} from 'react';
import {
  View,
  Text,
  TextInput,
  Button,
  Alert,
  StyleSheet,
} from 'react-native';
import {Picker} from '@react-native-picker/picker';
import {datasource} from './Data.js';

const Edit = ({navigation, route}) => {
  const [name, setName] = useState(route.params.key);
  const [description, setDescription] = useState(route.params.description);
  const [type, setType] = useState(route.params.type);
  const [image, setImage] = useState(route.params.image);

  return (
    <View style={styles.container}>
      <Text style={styles.title}>EDIT CAR</Text>

      <Text style={styles.label}>Car Name:</Text>
      <TextInput
        style={styles.input}
        value={name}
        onChangeText={(text) => setName(text)}
      />

      <Text style={styles.label}>Description:</Text>
      <TextInput
        style={styles.input}
        value={description}
        onChangeText={(text) => setDescription(text)}
      />

      <Text style={styles.label}>Category:</Text>
      <Picker
        style={styles.picker}
        selectedValue={type}
        onValueChange={(value) => setType(value)}
      >
        <Picker.Item
          label="Japanese Sports Cars"
          value="JAPANESE SPORTS CARS"
        />
        <Picker.Item
          label="European Sports Cars"
          value="EUROPEAN SPORTS CARS"
        />
      </Picker>

      <Text style={styles.label}>Car Image:</Text>
      <Picker
        style={styles.picker}
        selectedValue={image}
        onValueChange={(value) => setImage(value)}
      >
        <Picker.Item label="Nissan GT-R" value="nissan" />
        <Picker.Item label="Toyota Supra" value="supra" />
        <Picker.Item label="Porsche 911" value="porsche" />
        <Picker.Item label="BMW M4" value="bmw" />
      </Picker>

      <View style={styles.buttonRow}>
        <View style={styles.button}>
          <Button
            title="Save"
            onPress={() => {
              let picture = require('./img/nissan.jpg');

              if (image == 'supra') {
                picture = require('./img/supra.jpg');
              }
              if (image == 'porsche') {
                picture = require('./img/porsche.jpg');
              }
              if (image == 'bmw') {
                picture = require('./img/bmw.jpg');
              }

              let oldIndex = 1;

              if (route.params.type == 'JAPANESE SPORTS CARS') {
                oldIndex = 0;
              }

              let newIndex = 1;

              if (type == 'JAPANESE SPORTS CARS') {
                newIndex = 0;
              }

              let item = {
                key: name,
                description: description,
                image: image,
                picture: picture,
              };

              if (oldIndex == newIndex) {
                datasource[oldIndex].data[route.params.index] = item;
              } else {
                datasource[oldIndex].data.splice(route.params.index, 1);
                datasource[newIndex].data.push(item);
              }

              navigation.navigate('Home', {
                refresh: Date.now(),
              });
            }}
          />
        </View>

        <View style={styles.button}>
          <Button
            title="Delete"
            onPress={() => {
              let indexnum = 1;

              if (route.params.type == 'JAPANESE SPORTS CARS') {
                indexnum = 0;
              }

              Alert.alert(
                'Are you sure?',
                '',
                [
                  {
                    text: 'Yes',
                    onPress: () => {
                      datasource[indexnum].data.splice(
                        route.params.index, 1
                      );

                      navigation.navigate('Home', {
                        refresh: Date.now(),
                      });
                    },
                  },
                  {
                    text: 'No',
                  },
                ]
              );
            }}
          />
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F2F2F2',
    padding: 20,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 20,
  },
  label: {
    fontSize: 16,
    marginTop: 12,
    marginBottom: 5,
  },
  input: {
    borderWidth: 1,
    borderColor: '#AAAAAA',
    backgroundColor: 'white',
    padding: 10,
  },
  picker: {
    backgroundColor: 'white',
  },
  buttonRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 20,
  },
  button: {
    flex: 1,
    margin: 5,
  },
});

export default Edit;
