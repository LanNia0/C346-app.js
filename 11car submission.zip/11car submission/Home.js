
import React from 'react';
import {
  View,
  Text,
  Image,
  Button,
  SectionList,
  TouchableOpacity,
  StyleSheet,
} from 'react-native';

import {datasource} from './Data.js';

const Home = ({navigation, route}) => {

  const renderItem = ({item, index, section}) => {
    return (
      <TouchableOpacity
        style={styles.carCard}
        onPress={() => {
          navigation.navigate('Edit', {
            index: index,
            type: section.title,
            key: item.key,
            description: item.description,
            image: item.image,
          });
        }}
      >
        <View style={styles.carInfo}>
          <Text style={styles.carName}>
            {item.key}
          </Text>

          <Text style={styles.carDescription}>
            {item.description}
          </Text>
        </View>

        <Image
          source={item.picture}
          style={styles.carImage}
          resizeMode="contain"
        />
      </TouchableOpacity>
    );
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>
        SPORTS CAR COLLECTION
      </Text>

      <Text style={styles.subtitle}>
        Explore Japanese and European Sports Cars
      </Text>

      <View style={styles.buttonContainer}>
        <Button
          title="Add Car"
          onPress={() => navigation.navigate('Add')}
        />
      </View>

      <SectionList
        key={route.params ? route.params.refresh : 0}
        sections={datasource}
        renderItem={renderItem}
        renderSectionHeader={({section: {title, bgcolor}}) => (
          <Text
            style={[
              styles.sectionHeader,
              {backgroundColor: bgcolor}
            ]}
          >
            {title}
          </Text>
        )}
        contentContainerStyle={styles.list}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F2F2F2',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    textAlign: 'center',
    marginTop: 35,
    marginBottom: 10,
  },
  subtitle: {
    fontSize: 16,
    color: '#666666',
    textAlign: 'center',
    marginBottom: 15,
  },
  buttonContainer: {
    marginHorizontal: 15,
    marginBottom: 15,
  },
  list: {
    paddingHorizontal: 12,
    paddingBottom: 30,
  },
  sectionHeader: {
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
    padding: 15,
    marginTop: 10,
    borderWidth: 1,
    borderColor: '#CCCCCC',
  },
  carCard: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: 'white',
    borderWidth: 1,
    borderColor: '#CCCCCC',
    padding: 12,
    marginBottom: 5,
  },
  carInfo: {
    flex: 1,
    marginRight: 10,
  },
  carName: {
    fontSize: 18,
    fontWeight: 'bold',
  },
  carDescription: {
    fontSize: 14,
    color: '#666666',
    marginTop: 8,
  },
  carImage: {
    width: 130,
    height: 120,
  },
});

export default Home;
